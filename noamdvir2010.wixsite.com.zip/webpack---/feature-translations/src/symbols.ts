export const name = 'translations' as const
