export const name = 'clientSdk' as const
