export const name = 'animationsWixCodeSdk' as const
export const namespace = 'animations' as const
