export const platformUpdatesFunctionsNames = ['setControllerProps', 'updateProps', 'updateStyles', 'updateStructure', 'handleRepeaterDataUpdate']
