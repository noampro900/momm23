export const CompEventSymbol = Symbol('eventSymbol')
