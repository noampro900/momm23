export const ReducedMotionSymbol = Symbol.for('reducedMotion')
