export const SsrPlatformConfigSym = Symbol('SsrPlatformConfigSym')
export const MainGridAppIdFetchSymbol = Symbol('MainGridAppIdFetch')
