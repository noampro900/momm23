export const BaseComponentSymbol = Symbol('BaseComponent')
