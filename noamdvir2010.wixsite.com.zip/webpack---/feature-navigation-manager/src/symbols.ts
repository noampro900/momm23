export const name = 'navigationManager' as const
export { NavigationManagerSymbol } from '@wix/thunderbolt-symbols'
