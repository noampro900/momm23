export const name = 'repeaters' as const
