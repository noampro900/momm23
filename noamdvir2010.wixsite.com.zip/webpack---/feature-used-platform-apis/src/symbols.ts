export const name = 'usedPlatformApis' as const
export const UsedPlatformApisSymbol = Symbol('UsedPlatformApis')
