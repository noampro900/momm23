import React from 'react'

export const Div = ({ children, ...props }: any) => <div {...props}>{children}</div>
