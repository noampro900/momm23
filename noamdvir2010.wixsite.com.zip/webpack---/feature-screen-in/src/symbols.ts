export const ScreenInInitCallbackSymbol = Symbol('ScreenIn')
export const ScreenInAPISymbol = Symbol('ScreenInAPI')

export const name = 'screenIn' as const

export const SCREEN_IN_CALLBACK = 'screenInCallback'
