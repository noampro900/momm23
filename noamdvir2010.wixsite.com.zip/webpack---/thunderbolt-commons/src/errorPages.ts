export const errorPagesIds: { [key: string]: string } = {
	_403_dp: '_403_dp',
	_404_dp: '_404_dp',
	_500_dp: '_500_dp',
	_uknown_error_dp: '_uknown_error_dp',
}
