export const DEFAULT_DURATIONS_MS = {
	SlideHorizontal: 600,
	SlideVertical: 600,
	CrossFade: 600,
	OutIn: 700,
}
