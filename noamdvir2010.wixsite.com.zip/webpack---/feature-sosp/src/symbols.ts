export const name = 'sosp' as const
