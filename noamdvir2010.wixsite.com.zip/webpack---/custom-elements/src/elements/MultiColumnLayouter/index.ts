import MultiColumnLayouter from './MultiColumnLayouter'

export const customElementName = 'multi-column-layouter'

export default () => {
	return MultiColumnLayouter
}
